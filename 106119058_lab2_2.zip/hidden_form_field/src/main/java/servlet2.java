

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
/**
 * Servlet implementation class servlet2
 */
public class servlet2  extends HttpServlet {  
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) {  
		try{  
			response.setContentType("text/html");  
			PrintWriter out = response.getWriter();  
			//Getting the value from the hidden field  
			String n=request.getParameter("uname");
			out.print("<br> <h1>User Name tracked Using Hidden Form Field</h1>");
			out.print("<br><h3>Hello "+n+"</h3>");  
			out.close();  
		}catch(Exception e){System.out.println(e);}  
	} 
}
